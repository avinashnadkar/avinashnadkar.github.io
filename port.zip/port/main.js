const navslide = () =>{
    const hamburger = document.querySelector(".burger-menu");
    const navlinks = document.querySelector(".navi");

    hamburger.addEventListener("click", () => {
        navlinks.classList.toggle("open")
        })
}

navslide()
